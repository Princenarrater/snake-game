#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <unistd.h>
#include <termios.h>
#include <fcntl.h>

using namespace std;

const int width = 40;
const int height = 20;
int x, y, foodX, foodY, score, speed = 200000;
char dir = 'd';
bool gameOver = false;
bool paused = false;

vector<pair<int, int>> snake;
vector<pair<int, int>> obstacles;

void setNonBlockingInput() {
    termios term;
    tcgetattr(STDIN_FILENO, &term);
    term.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &term);
    fcntl(STDIN_FILENO, F_SETFL, O_NONBLOCK);
}

void resetTerminal() {
    termios term;
    tcgetattr(STDIN_FILENO, &term);
    term.c_lflag |= (ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &term);
}

bool isOccupied(int x, int y) {
    for (auto& s : snake)
        if (s.first == x && s.second == y) return true;
    for (auto& o : obstacles)
        if (o.first == x && o.second == y) return true;
    return false;
}

void setup() {
    srand(time(0));
    x = width / 2;
    y = height / 2;
    score = 0;
    dir = 'd';
    snake.clear();
    snake.push_back({x, y});
    
    // Place food
    do {
        foodX = rand() % width;
        foodY = rand() % height;
    } while (isOccupied(foodX, foodY));

    // Generate obstacles
    obstacles.clear();
    for (int i = 0; i < 10; i++) {
        int ox, oy;
        do {
            ox = rand() % width;
            oy = rand() % height;
        } while (isOccupied(ox, oy));
        obstacles.push_back({ox, oy});
    }
}

void draw() {
    system("clear");

    // Top wall
    for (int i = 0; i < width + 2; i++) cout << "\033[1;36m#\033[0m";
    cout << "\n";

    for (int i = 0; i < height; i++) {
        cout << "\033[1;36m#\033[0m";  // Left wall
        for (int j = 0; j < width; j++) {
            bool printed = false;
            if (i == y && j == x) {
                cout << "\033[1;32mO\033[0m"; // Head
                printed = true;
            } else if (i == foodY && j == foodX) {
                cout << "\033[1;31m*\033[0m"; // Food
                printed = true;
            } else {
                for (int k = 1; k < snake.size(); k++) {
                    if (snake[k].first == j && snake[k].second == i) {
                        cout << "\033[0;32mo\033[0m"; // Body
                        printed = true;
                        break;
                    }
                }
                if (!printed) {
                    for (auto& o : obstacles) {
                        if (o.first == j && o.second == i) {
                            cout << "\033[1;37mX\033[0m"; // Obstacle
                            printed = true;
                            break;
                        }
                    }
                }
            }
            if (!printed) cout << " ";
        }
        cout << "\033[1;36m#\033[0m\n";  // Right wall
    }

    for (int i = 0; i < width + 2; i++) cout << "\033[1;36m#\033[0m";
    cout << "\nScore: " << score << " | Speed: " << 200000 / speed << "x\n";

    if (paused) {
        cout << "\n\033[1;33m[PAUSED] Press 'p' to resume.\033[0m\n";
    }
}

void logic() {
    int newX = x;
    int newY = y;

    switch (dir) {
        case 'w': newY--; break;
        case 's': newY++; break;
        case 'a': newX--; break;
        case 'd': newX++; break;
        default: return;
    }

    // Wall or self collision
    if (newX < 0 || newX >= width || newY < 0 || newY >= height) {
        gameOver = true;
        return;
    }
    for (int i = 1; i < snake.size(); i++) {
        if (snake[i].first == newX && snake[i].second == newY) {
            gameOver = true;
            return;
        }
    }

    // Obstacle collision
    for (auto& o : obstacles) {
        if (o.first == newX && o.second == newY) {
            gameOver = true;
            return;
        }
    }

    x = newX;
    y = newY;
    snake.insert(snake.begin(), {x, y});


    if (x == foodX && y == foodY) {
        
        score += 10;
        int lastMilestone = 0;
        if (score >= lastMilestone + 50 && speed > 50000) {
    speed -= 20000;
    lastMilestone += 50;
}

        do {
            foodX = rand() % width;
            foodY = rand() % height;
        } while (isOccupied(foodX, foodY));
    } else {
        snake.pop_back();
    }
}

int main() {
    setup();
    setNonBlockingInput();

    while (!gameOver) {
        draw();
        usleep(speed);

        char key;
        if (read(STDIN_FILENO, &key, 1) == 1) {
            if (key == 'p') {
                paused = !paused; // Toggle pause
            } else if (!paused) {
                if ((key == 'w' && dir != 's') || (key == 's' && dir != 'w') ||
                    (key == 'a' && dir != 'd') || (key == 'd' && dir != 'a'))
                    dir = key;
            }
        }

        if (!paused) {
            logic();
        }
    }

    resetTerminal();
    cout << "\n\033[1;31mGame Over!\033[0m Final Score: " << score << endl;
    return 0;
}
